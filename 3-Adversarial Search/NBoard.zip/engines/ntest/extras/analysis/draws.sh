./ntest x < draws.cmds | grep "<" > draws.txt
source drawAnalysis.sh
